SAMPFUNCS v5.7.1 (SA-MP 0.3.7-R1; SA-MP 0.3.7-R3-1; SA-MP 0.3.7-R5; SA-MP 0.3.DL)

Copyright (c) 2012, BlastHack Team <blast.hk>

https://blast.hk/sampfuncs/
https://wiki.blast.hk/sampfuncs


- Installation
1. Make sure you have CLEO v4.1 (or greater) and ASI Loader.
2. Unpack SAMPFUNCS.asi of the corresponding SA-MP version into the root directory of your GTA: San Andreas installation.
